# Modelo FACENS para Overleaf

Arquivos:

- `main.tex`: arquivo principal de compilação.
- `configuracao.tex`: margens, fontes, paginação, espaçamentos e comandos do modelo.
- `texto.tex`: conteúdo do modelo; é o arquivo principal para edição do TCC/artigo.
- `imagens/`: imagens extraídas do documento original apenas para reproduzir os exemplos do modelo.

## Compilação

Use **XeLaTeX**.

No Overleaf: `Menu -> Compiler -> XeLaTeX`.

O arquivo usa diretamente a família `Arial`, conforme o modelo FACENS.
